# shared-ui-table-skeleton

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test shared-ui-table-skeleton` to execute the unit tests.
