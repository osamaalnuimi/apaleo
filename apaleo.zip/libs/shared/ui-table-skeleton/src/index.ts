export * from './lib/table-skeleton.component';
