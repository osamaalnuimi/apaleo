# users-ui-user-list-entry

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test users-ui-user-list-entry` to execute the unit tests.
